package com.acs560.restaurantsales.restaurant_sales.services;

public interface SalesAnalysisService {

}
