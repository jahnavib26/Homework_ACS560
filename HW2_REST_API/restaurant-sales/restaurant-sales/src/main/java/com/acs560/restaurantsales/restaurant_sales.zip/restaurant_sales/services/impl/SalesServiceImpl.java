package com.acs560.restaurantsales.restaurant_sales.services.impl;

public interface SalesServiceImpl {

}
