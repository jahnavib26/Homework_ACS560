package com.acs560.restaurantsales.restaurant_sales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantSalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
