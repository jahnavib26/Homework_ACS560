package com.acs560.restaurantsales.restaurant_sales.models;

public class Sales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
