package com.acs560.restaurantsales.restaurant_sales.controllers;

public class SalesAnalysisController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
